// If using Program.cs in .NET 6+

using OtpApi.Services;

var builder = WebApplication.CreateBuilder(args);

// Register the IOtpService with its implementation
builder.Services.AddScoped<IOtpService, OtpService>();
//builder.Services.AddScoped<IOtpRepository, OtpRepository>();

builder.Services.AddControllers();

var app = builder.Build();

app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseAuthorization();

app.MapControllers();

app.Run();
