﻿using Microsoft.AspNetCore.Mvc;
using OtpApi.Models;
using OtpApi.Services;

namespace OtpApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OtpController : ControllerBase
    {
        private readonly IOtpService _otpService;

        public OtpController(IOtpService otpService)
        {
            _otpService = otpService;
        }

        [HttpPost("generate")]
        public IActionResult GenerateOtp([FromBody] OtpRequest request)
        {
            if (string.IsNullOrEmpty(request.UserId))
                return BadRequest("UserId is required.");

            var otpResponse = _otpService.GenerateOtp(request.UserId);
            return Ok(new { otpResponse.Otp, ExpiresIn = (otpResponse.ExpiryTime - DateTime.UtcNow).TotalSeconds });
        }

        [HttpPost("validate")]
        public IActionResult ValidateOtp([FromBody] OtpRequest request, [FromQuery] string otp)
        {
            if (string.IsNullOrEmpty(request.UserId) || string.IsNullOrEmpty(otp))
                return BadRequest("UserId and OTP are required.");

            var isValid = _otpService.ValidateOtp(request.UserId, otp);
            return Ok(new { IsValid = isValid });
        }
    }

}