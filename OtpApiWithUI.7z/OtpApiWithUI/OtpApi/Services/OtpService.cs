﻿using Microsoft.AspNetCore.Http;
using OtpApi.Models;
using System;

namespace OtpApi.Services
{
   

    public class OtpService : IOtpService
    {
        private static Dictionary<string, OtpResponse> _otpStore = new Dictionary<string, OtpResponse>();
        private readonly int _otpValiditySeconds = 30;

        public OtpResponse GenerateOtp(string userId)
        {
            var otp = new Random().Next(100000, 999999).ToString();
            var expiryTime = DateTime.UtcNow.AddSeconds(_otpValiditySeconds);

            var otpResponse = new OtpResponse { Otp = otp, ExpiryTime = expiryTime };
            _otpStore[userId] = otpResponse;

            return otpResponse;
        }

        public bool ValidateOtp(string userId, string otp)
        {
            if (_otpStore.TryGetValue(userId, out var storedOtp))
            {
                if (storedOtp.Otp == otp && DateTime.UtcNow <= storedOtp.ExpiryTime)
                {
                    _otpStore.Remove(userId);
                    return true;
                }
            }
            return false;
        }
    }

}
