﻿using Microsoft.AspNetCore.Http;
using OtpApi.Models;

namespace OtpApi.Services
{
    public interface IOtpService
    {
        OtpResponse GenerateOtp(string userId);
        bool ValidateOtp(string userId, string otp);
    }
}
