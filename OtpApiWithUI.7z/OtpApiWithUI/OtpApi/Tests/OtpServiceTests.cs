﻿
using OtpApi.Services;
using Xunit;

namespace OtpApi.Tests
{
    public class OtpServiceTests
    {
        private readonly IOtpService _otpService;

        public OtpServiceTests()
        {
            _otpService = new OtpService();
        }

        [Fact]
        public void GenerateOtp_ShouldReturnValidOtp()
        {
            var userId = "test_user";
            var otpResponse = _otpService.GenerateOtp(userId);

            Assert.NotNull(otpResponse.Otp);
            Assert.True(otpResponse.ExpiryTime > DateTime.UtcNow);
        }

        [Fact]
        public void ValidateOtp_ShouldReturnTrueForValidOtp()
        {
            var userId = "test_user";
            var otpResponse = _otpService.GenerateOtp(userId);

            var isValid = _otpService.ValidateOtp(userId, otpResponse.Otp);

            Assert.True(isValid);
        }

        [Fact]
        public void ValidateOtp_ShouldReturnFalseForExpiredOtp()
        {
            var userId = "test_user";
            var otpResponse = _otpService.GenerateOtp(userId);

            // Simulate delay
            Thread.Sleep(31000);

            var isValid = _otpService.ValidateOtp(userId, otpResponse.Otp);

            Assert.False(isValid);
        }
    }

}
