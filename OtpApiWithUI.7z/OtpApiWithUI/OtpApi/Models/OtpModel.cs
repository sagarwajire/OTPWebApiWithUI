﻿namespace OtpApi.Models
{
    public class OtpResponse
    {
        public string Otp { get; set; }
        public DateTime ExpiryTime { get; set; }
    }

    public class OtpRequest
    {
        public string UserId { get; set; }
    }
}
